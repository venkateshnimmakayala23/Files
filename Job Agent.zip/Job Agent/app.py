import os
import re
import time
import random
import logging
from flask import Flask, render_template, request, jsonify
from playwright.sync_api import sync_playwright, TimeoutError as PlaywrightTimeout

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
app = Flask(__name__)
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Dedicated Playwright profile directory (persists LinkedIn login across runs)
PROFILE_DIR = os.path.join(os.path.expanduser("~"), ".linkedin-playwright-profile")
os.makedirs(PROFILE_DIR, exist_ok=True)

EMAIL_REGEX = re.compile(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}')

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def extract_emails(text: str) -> list[str]:
    """Return unique, lowercased email addresses found in *text*."""
    emails = EMAIL_REGEX.findall(text)
    seen: set[str] = set()
    unique: list[str] = []
    for email in emails:
        email = email.lower().rstrip('.')
        if email not in seen:
            seen.add(email)
            unique.append(email)
    return unique


def is_gmail(email: str) -> bool:
    """Check if an email belongs to Gmail."""
    return "@gmail" in email.lower()


def _human_delay(lo: float = 1.0, hi: float = 3.0):
    """Sleep for a random interval to mimic human behaviour."""
    time.sleep(random.uniform(lo, hi))


# ---------------------------------------------------------------------------
# Playwright scraping logic
# ---------------------------------------------------------------------------

def scrape_linkedin(keyword: str, scroll_count: int = 5) -> dict:
    """
    Open LinkedIn in an existing (persistent) browser profile, search for
    *keyword* in posts from the past 24 hours, and return extracted emails.
    """
    result = {
        "success": False,
        "keyword": keyword,
        "total_posts_scanned": 0,
        "emails": [],
        "gmail_filtered": [],
        "post_data": [],
        "error": None,
    }

    with sync_playwright() as p:
        context = None
        try:
            # Launch with persistent profile so LinkedIn session is reused
            context = p.chromium.launch_persistent_context(
                user_data_dir=PROFILE_DIR,
                channel="chrome",
                headless=False,
                args=[
                    "--disable-blink-features=AutomationControlled",
                    "--no-first-run",
                    "--no-default-browser-check",
                ],
                viewport={"width": 1280, "height": 900},
                ignore_default_args=["--enable-automation"],
            )

            page = context.pages[0] if context.pages else context.new_page()

            # ------ Navigate to LinkedIn search ------
            search_url = (
                "https://www.linkedin.com/search/results/content/"
                f"?keywords={keyword}"
                "&datePosted=%22past-24h%22"
                "&sortBy=%22date_posted%22"
                "&origin=FACETED_SEARCH"
            )
            logger.info("Navigating to: %s", search_url)
            page.goto(search_url, wait_until="domcontentloaded", timeout=60000)
            _human_delay(3, 5)

            # ------ Check login state ------
            if "login" in page.url or "checkpoint" in page.url:
                result["error"] = (
                    "NOT_LOGGED_IN: Please run the app once, log into LinkedIn "
                    "in the browser that opens, then restart the search."
                )
                # Keep browser open so user can log in manually
                logger.warning("LinkedIn login required — waiting 120 s for manual login …")
                page.wait_for_url("**/feed/**", timeout=120000)
                # After login, retry the search
                page.goto(search_url, wait_until="domcontentloaded", timeout=60000)
                _human_delay(3, 5)

            # ------ Wait for results container ------
            try:
                page.wait_for_selector(
                    "div.search-results-container, div.scaffold-finite-scroll",
                    timeout=15000,
                )
            except PlaywrightTimeout:
                result["error"] = "Timed out waiting for search results to load."
                return result

            # ------ Scroll to load more posts ------
            for i in range(scroll_count):
                logger.info("Scroll %d/%d", i + 1, scroll_count)
                page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
                _human_delay(2, 4)

                # Click any "See more" / "…more" buttons to expand truncated posts
                see_more_buttons = page.locator(
                    "button.feed-shared-inline-show-more-text, "
                    "button[aria-label*='more'], "
                    "button.see-more"
                )
                for j in range(see_more_buttons.count()):
                    try:
                        btn = see_more_buttons.nth(j)
                        if btn.is_visible():
                            btn.click()
                            _human_delay(0.3, 0.8)
                    except Exception:
                        pass

            # ------ Extract post text ------
            selectors = [
                "div.feed-shared-update-v2 span.break-words",
                "div.update-components-text span.break-words",
                "div.feed-shared-text span.break-words",
                "[data-urn] span.break-words",
                "span.break-words",
            ]

            post_texts: list[str] = []
            for selector in selectors:
                elements = page.locator(selector)
                count = elements.count()
                if count > 0:
                    for k in range(count):
                        try:
                            txt = elements.nth(k).inner_text(timeout=3000)
                            if txt and len(txt.strip()) > 10:
                                post_texts.append(txt.strip())
                        except Exception:
                            pass
                    break  # use first selector that works

            # Deduplicate post texts
            seen_texts: set[str] = set()
            unique_posts: list[str] = []
            for t in post_texts:
                sig = t[:200]
                if sig not in seen_texts:
                    seen_texts.add(sig)
                    unique_posts.append(t)

            result["total_posts_scanned"] = len(unique_posts)
            logger.info("Extracted %d unique posts", len(unique_posts))

            # ------ Extract emails from posts ------
            all_emails: list[str] = []
            gmail_list: list[str] = []

            for post_text in unique_posts:
                emails_in_post = extract_emails(post_text)
                if emails_in_post:
                    non_gmail = [e for e in emails_in_post if not is_gmail(e)]
                    gmail = [e for e in emails_in_post if is_gmail(e)]
                    gmail_list.extend(gmail)
                    all_emails.extend(non_gmail)

                    result["post_data"].append({
                        "text": post_text[:500],
                        "emails": non_gmail,
                        "gmail": gmail,
                    })

            # Deduplicate final lists
            result["emails"] = list(dict.fromkeys(all_emails))
            result["gmail_filtered"] = list(dict.fromkeys(gmail_list))
            result["success"] = True

        except PlaywrightTimeout:
            result["error"] = "Browser operation timed out. LinkedIn may be slow or blocking automation."
        except Exception as exc:
            logger.exception("Scrape failed")
            result["error"] = str(exc)
        finally:
            if context:
                try:
                    context.close()
                except Exception:
                    pass

    return result


# ---------------------------------------------------------------------------
# Flask routes
# ---------------------------------------------------------------------------

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/search", methods=["POST"])
def api_search():
    data = request.get_json(force=True)
    keyword = data.get("keyword", "").strip()

    if not keyword:
        return jsonify({"success": False, "error": "Keyword is required."}), 400

    scroll_count = int(data.get("scroll_count", 5))
    result = scrape_linkedin(keyword, scroll_count=scroll_count)
    return jsonify(result)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    app.run(debug=True, port=5000)
