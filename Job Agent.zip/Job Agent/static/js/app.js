// ================================================================
// LinkedIn Email Extractor — Frontend Logic
// ================================================================

(function () {
    "use strict";

    // ---------- DOM refs ----------
    const searchForm     = document.getElementById("search-form");
    const keywordInput   = document.getElementById("keyword-input");
    const searchBtn      = document.getElementById("search-btn");
    const btnText        = searchBtn.querySelector(".btn__text");
    const btnLoader      = searchBtn.querySelector(".btn__loader");

    const searchSection  = document.getElementById("search-section");
    const loadingSection = document.getElementById("loading-section");
    const resultsSection = document.getElementById("results-section");
    const errorSection   = document.getElementById("error-section");

    const loadingStatus  = document.getElementById("loading-status");
    const errorMessage   = document.getElementById("error-message");
    const retryBtn       = document.getElementById("retry-btn");

    const statPosts      = document.getElementById("stat-posts");
    const statEmails     = document.getElementById("stat-emails");
    const statGmail      = document.getElementById("stat-gmail");

    const emailGrid      = document.getElementById("email-grid");
    const noEmails       = document.getElementById("no-emails");
    const copyAllBtn     = document.getElementById("copy-all-btn");

    const gmailBlock     = document.getElementById("gmail-block");
    const gmailList      = document.getElementById("gmail-list");

    const postList       = document.getElementById("post-list");
    const noPosts        = document.getElementById("no-posts");

    const toastContainer = document.getElementById("toast-container");

    // ---------- State ----------
    let currentEmails = [];
    let loadingInterval = null;

    // ---------- Hint chips ----------
    document.querySelectorAll(".hint-chip").forEach((chip) => {
        chip.addEventListener("click", () => {
            keywordInput.value = chip.dataset.keyword;
            keywordInput.focus();
        });
    });

    // ---------- Retry button ----------
    retryBtn.addEventListener("click", () => {
        showSection("search");
        keywordInput.focus();
    });

    // ---------- Copy all ----------
    copyAllBtn.addEventListener("click", () => {
        if (currentEmails.length === 0) return;
        copyToClipboard(currentEmails.join("\n"));
        showToast(`Copied ${currentEmails.length} email${currentEmails.length > 1 ? "s" : ""} to clipboard`);
    });

    // ---------- Form submit ----------
    searchForm.addEventListener("submit", async (e) => {
        e.preventDefault();
        const keyword = keywordInput.value.trim();
        if (!keyword) return;

        setLoading(true);
        showSection("loading");
        startLoadingAnimation();

        try {
            const resp = await fetch("/api/search", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ keyword, scroll_count: 5 }),
            });

            const data = await resp.json();

            if (!resp.ok || !data.success) {
                throw new Error(data.error || "Unknown error occurred.");
            }

            renderResults(data);
            showSection("results");
        } catch (err) {
            errorMessage.textContent = err.message;
            showSection("error");
        } finally {
            setLoading(false);
            stopLoadingAnimation();
        }
    });

    // ---------- Section visibility ----------
    function showSection(name) {
        loadingSection.hidden = name !== "loading";
        resultsSection.hidden = name !== "results";
        errorSection.hidden   = name !== "error";
    }

    // ---------- Loading state ----------
    function setLoading(on) {
        searchBtn.disabled = on;
        btnText.hidden     = on;
        btnLoader.hidden   = !on;
    }

    function startLoadingAnimation() {
        const steps = [
            document.getElementById("step-1"),
            document.getElementById("step-2"),
            document.getElementById("step-3"),
            document.getElementById("step-4"),
        ];
        let current = 0;

        // Reset all steps
        steps.forEach((s) => { s.classList.remove("active", "done"); });
        steps[0].classList.add("active");

        loadingInterval = setInterval(() => {
            if (current < steps.length) {
                steps[current].classList.remove("active");
                steps[current].classList.add("done");
            }
            current++;
            if (current < steps.length) {
                steps[current].classList.add("active");
            } else {
                // loop back
                current = 0;
                steps.forEach((s) => s.classList.remove("done"));
                steps[0].classList.add("active");
            }
        }, 8000);
    }

    function stopLoadingAnimation() {
        if (loadingInterval) {
            clearInterval(loadingInterval);
            loadingInterval = null;
        }
    }

    // ---------- Render results ----------
    function renderResults(data) {
        // Stats
        animateNumber(statPosts, data.total_posts_scanned || 0);
        animateNumber(statEmails, (data.emails || []).length);
        animateNumber(statGmail, (data.gmail_filtered || []).length);

        // Emails
        currentEmails = data.emails || [];
        emailGrid.innerHTML = "";
        if (currentEmails.length === 0) {
            noEmails.hidden = false;
        } else {
            noEmails.hidden = true;
            currentEmails.forEach((email, i) => {
                const card = document.createElement("div");
                card.className = "email-card";
                card.style.animationDelay = `${i * 0.05}s`;
                card.innerHTML = `
                    <span class="email-card__address">${escapeHtml(email)}</span>
                    <button class="email-card__copy" title="Copy email" data-email="${escapeHtml(email)}">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <rect x="9" y="9" width="13" height="13" rx="2" ry="2"/>
                            <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>
                        </svg>
                    </button>
                `;
                emailGrid.appendChild(card);
            });

            // Copy individual email buttons
            emailGrid.querySelectorAll(".email-card__copy").forEach((btn) => {
                btn.addEventListener("click", () => {
                    copyToClipboard(btn.dataset.email);
                    showToast(`Copied: ${btn.dataset.email}`);
                });
            });
        }

        // Gmail filtered
        const gmails = data.gmail_filtered || [];
        if (gmails.length > 0) {
            gmailBlock.hidden = false;
            gmailList.innerHTML = "";
            gmails.forEach((email) => {
                const chip = document.createElement("span");
                chip.className = "gmail-chip";
                chip.textContent = email;
                gmailList.appendChild(chip);
            });
        } else {
            gmailBlock.hidden = true;
        }

        // Post context
        const posts = data.post_data || [];
        postList.innerHTML = "";
        if (posts.length === 0) {
            noPosts.hidden = false;
        } else {
            noPosts.hidden = true;
            posts.forEach((post, i) => {
                const item = document.createElement("div");
                item.className = "post-item";
                item.style.animationDelay = `${i * 0.08}s`;

                const emailTags = [
                    ...(post.emails || []).map(
                        (e) => `<span class="post-item__email-tag">${escapeHtml(e)}</span>`
                    ),
                    ...(post.gmail || []).map(
                        (e) => `<span class="post-item__email-tag post-item__email-tag--gmail">${escapeHtml(e)}</span>`
                    ),
                ].join("");

                item.innerHTML = `
                    <div class="post-item__text">${escapeHtml(truncate(post.text, 300))}</div>
                    <div class="post-item__emails">${emailTags}</div>
                `;
                postList.appendChild(item);
            });
        }
    }

    // ---------- Utilities ----------
    function copyToClipboard(text) {
        if (navigator.clipboard) {
            navigator.clipboard.writeText(text).catch(() => fallbackCopy(text));
        } else {
            fallbackCopy(text);
        }
    }

    function fallbackCopy(text) {
        const ta = document.createElement("textarea");
        ta.value = text;
        ta.style.position = "fixed";
        ta.style.left = "-9999px";
        document.body.appendChild(ta);
        ta.select();
        document.execCommand("copy");
        document.body.removeChild(ta);
    }

    function showToast(message) {
        const toast = document.createElement("div");
        toast.className = "toast";
        toast.textContent = message;
        toastContainer.appendChild(toast);

        setTimeout(() => {
            toast.classList.add("toast--exit");
            setTimeout(() => toast.remove(), 300);
        }, 2500);
    }

    function escapeHtml(str) {
        const div = document.createElement("div");
        div.textContent = str;
        return div.innerHTML;
    }

    function truncate(str, max) {
        if (!str) return "";
        return str.length > max ? str.slice(0, max) + " …" : str;
    }

    function animateNumber(el, target) {
        const duration = 600;
        const start = 0;
        const startTime = performance.now();

        function update(currentTime) {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);
            const eased = 1 - Math.pow(1 - progress, 3);           // ease-out cubic
            el.textContent = Math.round(start + (target - start) * eased);
            if (progress < 1) requestAnimationFrame(update);
        }

        requestAnimationFrame(update);
    }
})();
